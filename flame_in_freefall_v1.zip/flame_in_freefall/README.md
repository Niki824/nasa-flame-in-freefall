# Flame in Freefall — V1 Prototype

AI-powered dashboard that turns microgravity combustion experiment data into
plain-language fire-safety insights, for the NASA Space Apps 2026 "Flame in
Freefall" challenge.

## What's here

- `data/experiments_sample.csv` — **prototype data only.** Hand-built from
  publicly documented characteristics of NASA's real BASS-II and FLEX-2
  microgravity combustion experiments (ISS operations reports). This is
  **not** the official challenge dataset — NASA releases the full challenge
  statement and real data on **October 28, 2026**. Replace this file with
  the real dataset then; the pipeline expects the same columns, so the rest
  of the code should keep working with minimal changes.
- `pipeline.py` — loads, cleans, and summarizes the data. The "AI summary"
  is currently rule-based (template sentences built from real row values)
  so it works offline with zero API cost or latency risk. See the comment
  in `summarize_row()` for how to layer an LLM on top later without letting
  it invent numbers.
- `app.py` — the Streamlit dashboard: metrics, filters, ranked experiment
  cards with AI summaries, and a spread-rate chart.
- `requirements.txt` — dependencies.

## Run it

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Scope notes (why this is deliberately small)

This is intentionally the **V1 / MVP scope only** — data → clean → rule-based
AI summary → dashboard. It does NOT include:

- ML-based pattern detection across variables
- A natural-language "Ask Flame AI" assistant
- Multi-experiment comparison view

Those are good **stretch goals** to mention as "future work" in the
hackathon pitch, but building a small thing that fully works beats an
ambitious thing that's half-finished — especially solo, in 48 hours.

## Before the hackathon (this week)

1. Watch for the October 28 full challenge statement + official datasets.
2. Swap `data/experiments_sample.csv` for the real data once released.
3. Check `pipeline.py`'s `REQUIRED_COLUMNS` against the real dataset's
   columns and adjust `clean_data()` / `summarize_row()` as needed.
4. Everything else (dashboard layout, metrics, chart) should keep working
   with little to no change, since it's built against the pipeline's
   output, not the raw file.

## Responsible framing

Summaries and safety notes describe **observed experimental conditions**
only — they never claim a material is inherently "dangerous" or "safe."
Keep this distinction if you extend the AI layer; it's the difference
between a NASA-appropriate insight tool and an overclaiming one.
