# Flame in Freefall — V1 Prototype

AI-powered dashboard that turns microgravity combustion experiment data into
plain-language fire-safety insights, for the NASA Space Apps 2026 "Flame in
Freefall" challenge.

## What's here

- `data/experiments_sample.csv` — **prototype data only.** Hand-built from
  publicly documented characteristics of NASA's real BASS-II and FLEX-2
  microgravity combustion experiments (ISS operations reports). This is
  **not** the official challenge dataset — NASA releases the full challenge
  statement and real data on **October 28, 2026**. Replace this file with
  the real dataset then; the pipeline expects the same columns, so the rest
  of the code should keep working with minimal changes.
- `pipeline.py` — loads, cleans, and summarizes the data. The "AI summary"
  is currently rule-based (template sentences built from real row values)
  so it works offline with zero API cost or latency risk. See the comment
  in `summarize_row()` for how to layer an LLM on top later without letting
  it invent numbers.
- `app.py` — the Streamlit dashboard: metrics, filters, ranked experiment
  cards with AI summaries, and a spread-rate chart.
- `requirements.txt` — dependencies.

## Run it

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Roadmap (built incrementally, on purpose)

- **V1 ✅ — Data → Dashboard.** Cleaning + rule-based text summaries. Labeled
  honestly in the UI as "rule-based" (not ML), since it's just templated
  sentences built from real row values — no model involved yet.
- **V2 ✅ — Data → Statistical Analysis → Dashboard.** `analysis.py` computes
  real Pearson correlations (oxygen % and airflow vs. spread rate) and
  labels each one with its strength *and* the sample size it's based on —
  with only 10 prototype rows, correlations are exploratory, not confirmed
  findings, and the dashboard says so rather than overclaiming.
- **V3 (stretch) — Add ML.** A real model (e.g. simple classifier/regressor)
  predicting flame behavior from oxygen/airflow/material/geometry, replacing
  hand-written correlation checks with learned pattern detection.
- **V4 (stretch) — "Ask Flame AI."** A natural-language Q&A layer that reads
  the *actual* structured data and V2/V3 analysis results, and is only
  allowed to explain them — never to invent new numbers or claims.
- **V5 (stretch) — Official data + polish.** Swap in NASA's real dataset
  (released Oct 28) and refine the visual design.

**For the actual 48-hour hackathon, V1 + V2 is a safe, complete, honestly-labeled
project on its own.** V3/V4 are good "future work" lines for the pitch even if
unbuilt — judges respond well to a clear vision, but a working V1+V2 beats an
unfinished V4 every time, especially solo.

## Before the hackathon (this week)

1. Watch for the October 28 full challenge statement + official datasets.
2. Swap `data/experiments_sample.csv` for the real data once released.
3. Check `pipeline.py`'s `REQUIRED_COLUMNS` against the real dataset's
   columns and adjust `clean_data()` / `summarize_row()` as needed.
4. Everything else (dashboard layout, metrics, chart) should keep working
   with little to no change, since it's built against the pipeline's
   output, not the raw file.

## Responsible framing

Summaries and safety notes describe **observed experimental conditions**
only — they never claim a material is inherently "dangerous" or "safe."
Keep this distinction if you extend the AI layer; it's the difference
between a NASA-appropriate insight tool and an overclaiming one.
