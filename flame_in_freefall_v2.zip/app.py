"""
Flame in Freefall — V1 Dashboard (Streamlit)

Run with:  streamlit run app.py

This is the hackathon-scoped version: data explorer + AI summary + one chart.
No ML pattern detection, no natural-language assistant — those are noted as
"future work" in the sidebar so the story is complete without needing them.
"""

import streamlit as st
import pandas as pd
from pipeline import load_data, clean_data, build_report
from analysis import variable_relationships

st.set_page_config(page_title="Flame in Freefall", page_icon="🔥", layout="wide")

st.title("🔥 Flame in Freefall")
st.subheader("NASA Microgravity Combustion Intelligence")
st.caption(
    "Prototype dashboard using illustrative data based on documented BASS-II / "
    "FLEX-2 experiment characteristics. Not official NASA challenge data — "
    "swap in the real dataset once released (Oct 28)."
)

# --- Load & process data ---
raw = load_data("data/experiments_sample.csv")
cleaned = clean_data(raw)
report = build_report(cleaned)

# --- Top metrics ---
col1, col2, col3 = st.columns(3)
col1.metric("Experiments analyzed", len(report))
col2.metric("Missions covered", report["mission"].nunique())
col3.metric("Self-extinguished", int(report["extinguished"].sum()))

st.divider()

# --- Sidebar filters ---
st.sidebar.header("Experiment Explorer")
mission_filter = st.sidebar.multiselect(
    "Mission", options=sorted(report["mission"].unique()), default=list(report["mission"].unique())
)
material_filter = st.sidebar.multiselect(
    "Material", options=sorted(report["material"].unique()), default=list(report["material"].unique())
)

filtered = report[
    report["mission"].isin(mission_filter) & report["material"].isin(material_filter)
]

st.sidebar.divider()
st.sidebar.caption(
    "**Future work (not built for this hackathon):**\n"
    "- ML pattern detection across variables\n"
    "- Natural-language 'Ask Flame AI' assistant\n"
    "- Experiment-to-experiment comparison view"
)

# --- Main: ranked table + chart ---
left, right = st.columns([2, 1])

with left:
    st.markdown("### Ranked by observed flame spread rate")
    for _, row in filtered.iterrows():
        with st.container(border=True):
            st.markdown(f"**{row['experiment_id']}** — {row['material']} ({row['mission']})")
            st.write(row["ai_summary"])
            st.caption("↑ rule-based summary, generated from the row's real values (not yet ML)")
            st.info(row["safety_note"])
            st.caption(f"Source: {row['source_note']}")

with right:
    st.markdown("### Spread rate by experiment")
    chart_data = filtered.set_index("experiment_id")["spread_rate_mm_s"]
    st.bar_chart(chart_data)

    st.markdown("### Raw data")
    st.dataframe(filtered.drop(columns=["ai_summary", "safety_note"]), use_container_width=True)

st.divider()

# --- V2: real statistical analysis (not rule-based text — actual correlation) ---
st.markdown("## 📊 Statistical Analysis")
st.caption(
    "This section reports actual computed correlations — it does not use the "
    "rule-based summary logic above. Every relationship below is labeled with "
    "its real strength AND the sample size it's based on, so a weak or noisy "
    "signal can't be mistaken for a confirmed finding."
)

rel_col1, rel_col2 = st.columns(2)
scatter_col1, scatter_col2 = st.columns(2)

relationships = variable_relationships(filtered)
for rel, col in zip(relationships, [rel_col1, rel_col2]):
    with col:
        st.metric(
            label=f"{rel['variable']} vs. spread rate",
            value=rel["label"],
        )
        st.caption(rel["caveat"])

with scatter_col1:
    st.markdown("**Oxygen % vs. Spread rate**")
    st.scatter_chart(filtered, x="oxygen_pct", y="spread_rate_mm_s")

with scatter_col2:
    st.markdown("**Airflow vs. Spread rate**")
    st.scatter_chart(filtered, x="airflow_cms", y="spread_rate_mm_s")
