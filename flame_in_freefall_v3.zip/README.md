# Flame in Freefall — V1 Prototype

AI-powered dashboard that turns microgravity combustion experiment data into
plain-language fire-safety insights, for the NASA Space Apps 2026 "Flame in
Freefall" challenge.

## What's here

- `data/experiments_sample.csv` — **prototype data only.** Hand-built from
  publicly documented characteristics of NASA's real BASS-II and FLEX-2
  microgravity combustion experiments (ISS operations reports). This is
  **not** the official challenge dataset — NASA releases the full challenge
  statement and real data on **October 28, 2026**. Replace this file with
  the real dataset then; the pipeline expects the same columns, so the rest
  of the code should keep working with minimal changes.
- `pipeline.py` — loads, cleans, and summarizes the data. The "experiment
  summary" is currently rule-based (template sentences built from real row
  values), labeled honestly in the UI as such — no model involved yet.
  Also includes `compare_experiments()`, a rule-based side-by-side
  comparison of two experiments.
- `analysis.py` — real Pearson correlations, each labeled with strength
  *and* sample size so a weak/noisy signal isn't mistaken for a finding.
- `ml_model.py` — a real decision tree predicting whether a flame
  self-extinguishes, evaluated with **leave-one-out cross-validation**
  (the honest choice for a 10-row dataset — a normal train/test split would
  test on ~2 rows). With this little data it currently scores ~50% accuracy
  (coin-flip) — that's a correct, expected result given the sample size, not
  a bug, and the UI says so explicitly.
- `app.py` — the Streamlit dashboard: metrics, filters, ranked experiment
  cards, statistical analysis, ML pattern detection, and experiment compare.
- `requirements.txt` — dependencies.

## Run it

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Roadmap (built incrementally, on purpose)

- **V1 ✅ — Data → Dashboard.** Cleaning + rule-based text summaries. Labeled
  honestly in the UI as "rule-based" (not ML), since it's just templated
  sentences built from real row values — no model involved yet.
- **V2 ✅ — Data → Statistical Analysis → Dashboard.** `analysis.py` computes
  real Pearson correlations (oxygen % and airflow vs. spread rate) and
  labels each one with its strength *and* the sample size it's based on —
  with only 10 prototype rows, correlations are exploratory, not confirmed
  findings, and the dashboard says so rather than overclaiming.
- **V3 ✅ — Add ML.** `ml_model.py` trains a decision tree predicting
  "extinguished" from oxygen/airflow/material/geometry, validated with
  leave-one-out CV (honest for n=10 — not enough rows for a normal
  train/test split). Current accuracy is ~50% (coin-flip) — an expected,
  correctly-labeled result of too little data, not a real predictive
  finding yet. `app.py` also adds an **Experiment Compare** feature:
  pick two experiments, get a side-by-side table plus a rule-based
  "observed difference" narrative (never claims causation).
- **V4 (stretch) — "Ask Flame AI."** A natural-language Q&A layer that reads
  the *actual* structured data and V2/V3 analysis results, and is only
  allowed to explain them — never to invent new numbers or claims.
- **V5 (stretch) — Official data + polish.** Swap in NASA's real dataset
  (released Oct 28) and refine the visual design.

**For the actual 48-hour hackathon, V1 + V2 + V3 is a complete, honestly-labeled
project on its own.** V4/V5 are good "future work" lines for the pitch even if
unbuilt — judges respond well to a clear vision, but a working V1–V3 beats an
unfinished V4/V5 every time, especially solo.

## Before the hackathon (this week)

1. Watch for the October 28 full challenge statement + official datasets.
2. Swap `data/experiments_sample.csv` for the real data once released.
3. Check `pipeline.py`'s `REQUIRED_COLUMNS` against the real dataset's
   columns and adjust `clean_data()` / `summarize_row()` as needed.
4. Everything else (dashboard layout, metrics, chart) should keep working
   with little to no change, since it's built against the pipeline's
   output, not the raw file.

## Responsible framing

Summaries and safety notes describe **observed experimental conditions**
only — they never claim a material is inherently "dangerous" or "safe."
Keep this distinction if you extend the AI layer; it's the difference
between a NASA-appropriate insight tool and an overclaiming one.
