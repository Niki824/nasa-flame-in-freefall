"""
Flame in Freefall — V2 statistical analysis module

This adds REAL statistics on top of the V1 pipeline (V1 was cleaning +
rule-based text summaries only — no analysis). Keep this separate from
pipeline.py so the "data cleaning" and "data analysis" concerns don't get
tangled together as the project grows.

Design principle carried over from V1: never claim more than the numbers
support. With a small sample (our prototype has 10 rows — the real NASA
dataset should have more), a correlation can look interesting without being
statistically meaningful. We label the strength AND the sample size
together, every time, so the dashboard can't accidentally overstate a
weak/noisy signal as a discovery.
"""

import pandas as pd

NUMERIC_COLUMNS = ["oxygen_pct", "airflow_cms", "spread_rate_mm_s"]


def correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """Pearson correlation between the numeric experiment variables."""
    return df[NUMERIC_COLUMNS].corr()


def describe_correlation(r: float) -> str:
    """Turn a raw correlation coefficient into a plain-language strength label."""
    magnitude = abs(r)
    if magnitude < 0.2:
        strength = "negligible"
    elif magnitude < 0.4:
        strength = "weak"
    elif magnitude < 0.6:
        strength = "moderate"
    elif magnitude < 0.8:
        strength = "strong"
    else:
        strength = "very strong"
    direction = "positive" if r >= 0 else "negative"
    return f"{strength} {direction} (r = {r:.2f})"


def variable_relationships(df: pd.DataFrame) -> list[dict]:
    """
    Build a list of {pair, correlation, label, caveat} for each variable pair
    against spread_rate_mm_s specifically, since that's the outcome we care
    about explaining.
    """
    corr = correlation_matrix(df)
    n = len(df)
    results = []
    for var in ["oxygen_pct", "airflow_cms"]:
        r = corr.loc[var, "spread_rate_mm_s"]
        results.append({
            "variable": var,
            "correlation": r,
            "label": describe_correlation(r),
            "caveat": (
                f"Based on only n={n} experiments — exploratory only, "
                "not a statistically confirmed relationship."
                if n < 30 else
                f"Based on n={n} experiments."
            ),
        })
    return results


if __name__ == "__main__":
    from pipeline import load_data, clean_data

    df = clean_data(load_data("data/experiments_sample.csv"))
    print("Correlation matrix:\n", correlation_matrix(df), "\n")
    for rel in variable_relationships(df):
        print(f"{rel['variable']} vs spread_rate_mm_s: {rel['label']}")
        print(f"  ({rel['caveat']})\n")
