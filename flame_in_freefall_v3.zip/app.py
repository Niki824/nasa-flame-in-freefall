"""
Flame in Freefall — V1 Dashboard (Streamlit)

Run with:  streamlit run app.py

This is the hackathon-scoped version: data explorer + experiment summary + one chart.
No ML pattern detection, no natural-language assistant — those are noted as
"future work" in the sidebar so the story is complete without needing them.
"""

import streamlit as st
import pandas as pd
from pipeline import load_data, clean_data, build_report, compare_experiments
from analysis import variable_relationships
from ml_model import train_and_evaluate, explain_result

st.set_page_config(page_title="Flame in Freefall", page_icon="🔥", layout="wide")

st.title("🔥 Flame in Freefall")
st.subheader("NASA Microgravity Combustion Intelligence")
st.caption(
    "Prototype dashboard using illustrative data based on documented BASS-II / "
    "FLEX-2 experiment characteristics. Not official NASA challenge data — "
    "swap in the real dataset once released (Oct 28)."
)

# --- Load & process data ---
raw = load_data("data/experiments_sample.csv")
cleaned = clean_data(raw)
report = build_report(cleaned)

# --- Top metrics ---
col1, col2, col3 = st.columns(3)
col1.metric("Experiments analyzed", len(report))
col2.metric("Missions covered", report["mission"].nunique())
col3.metric("Self-extinguished", int(report["extinguished"].sum()))

st.divider()

# --- Sidebar filters ---
st.sidebar.header("Experiment Explorer")
mission_filter = st.sidebar.multiselect(
    "Mission", options=sorted(report["mission"].unique()), default=list(report["mission"].unique())
)
material_filter = st.sidebar.multiselect(
    "Material", options=sorted(report["material"].unique()), default=list(report["material"].unique())
)

filtered = report[
    report["mission"].isin(mission_filter) & report["material"].isin(material_filter)
]

st.sidebar.divider()
st.sidebar.caption(
    "**Future work (not built for this hackathon):**\n"
    "- ML pattern detection across variables\n"
    "- Natural-language 'Ask Flame AI' assistant\n"
    "- Experiment-to-experiment comparison view"
)

# --- Main: ranked table + chart ---
left, right = st.columns([2, 1])

with left:
    st.markdown("### Ranked by observed flame spread rate")
    for _, row in filtered.iterrows():
        with st.container(border=True):
            st.markdown(f"**{row['experiment_id']}** — {row['material']} ({row['mission']})")
            st.write(row["experiment_summary"])
            st.caption("↑ rule-based summary, generated from the row's real values (not yet ML)")
            st.info(row["safety_note"])
            st.caption(f"Source: {row['source_note']}")

with right:
    st.markdown("### Spread rate by experiment")
    chart_data = filtered.set_index("experiment_id")["spread_rate_mm_s"]
    st.bar_chart(chart_data)

    st.markdown("### Raw data")
    st.dataframe(filtered.drop(columns=["experiment_summary", "safety_note"]), use_container_width=True)

st.divider()

# --- V2: real statistical analysis (not rule-based text — actual correlation) ---
st.markdown("## 📊 Statistical Analysis")
st.caption(
    "This section reports actual computed correlations — it does not use the "
    "rule-based summary logic above. Every relationship below is labeled with "
    "its real strength AND the sample size it's based on, so a weak or noisy "
    "signal can't be mistaken for a confirmed finding."
)

rel_col1, rel_col2 = st.columns(2)
scatter_col1, scatter_col2 = st.columns(2)

relationships = variable_relationships(filtered)
for rel, col in zip(relationships, [rel_col1, rel_col2]):
    with col:
        st.metric(
            label=f"{rel['variable']} vs. spread rate",
            value=rel["label"],
        )
        st.caption(rel["caveat"])

with scatter_col1:
    st.markdown("**Oxygen % vs. Spread rate**")
    st.scatter_chart(filtered, x="oxygen_pct", y="spread_rate_mm_s")

with scatter_col2:
    st.markdown("**Airflow vs. Spread rate**")
    st.scatter_chart(filtered, x="airflow_cms", y="spread_rate_mm_s")

st.divider()

# --- V3: ML pattern detection (honest about small-sample limits) ---
st.markdown("## 🤖 ML Pattern Detection")
ml_result = train_and_evaluate(cleaned)  # use full cleaned data, not the filtered subset
st.write(explain_result(ml_result))

imp_df = pd.DataFrame(
    sorted(ml_result["feature_importances"].items(), key=lambda x: -x[1]),
    columns=["feature", "importance"],
).set_index("feature")
st.bar_chart(imp_df)

if not ml_result["reliable"]:
    st.warning(
        f"Only {ml_result['n_samples']} training examples — this model is a working "
        f"architecture demo, not a validated predictor. Re-train once the official "
        f"NASA dataset (released Oct 28) is available."
    )

st.divider()

# --- Experiment Compare feature ---
st.markdown("## 🔬 Experiment Compare")
compare_col1, compare_col2 = st.columns(2)
with compare_col1:
    exp_a = st.selectbox("Experiment A", options=cleaned["experiment_id"], index=0)
with compare_col2:
    exp_b = st.selectbox("Experiment B", options=cleaned["experiment_id"], index=1)

if exp_a == exp_b:
    st.info("Choose two different experiments to compare.")
else:
    row_a = cleaned[cleaned["experiment_id"] == exp_a].iloc[0]
    row_b = cleaned[cleaned["experiment_id"] == exp_b].iloc[0]

    compare_table = pd.DataFrame({
        exp_a: [row_a["material"], row_a["sample_geometry"], row_a["oxygen_pct"],
                row_a["airflow_cms"], row_a["spread_rate_mm_s"],
                "Extinguished" if row_a["extinguished"] else "Sustained"],
        exp_b: [row_b["material"], row_b["sample_geometry"], row_b["oxygen_pct"],
                row_b["airflow_cms"], row_b["spread_rate_mm_s"],
                "Extinguished" if row_b["extinguished"] else "Sustained"],
    }, index=["Material", "Geometry", "Oxygen %", "Airflow (cm/s)", "Spread rate (mm/s)", "Outcome"])

    st.table(compare_table)
    st.info(compare_experiments(row_a, row_b))
