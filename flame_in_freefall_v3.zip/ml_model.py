"""
Flame in Freefall — V3 ML pattern detection module

WHY THIS MODULE LOOKS THE WAY IT DOES

With only 10 prototype rows (6 "not extinguished" / 4 "extinguished"), a
normal train/test split (e.g. 80/20) would test on ~2 rows — meaningless.
A model can also trivially "memorize" 10 rows and look perfect while
learning nothing real. So instead of faking a confident train/test split,
we use LEAVE-ONE-OUT CROSS-VALIDATION: train on 9 rows, predict the 1 left
out, repeat for every row, then average. This is the standard honest
approach for very small datasets, and it still won't produce a reliable
model — it will tell us HOW unreliable, which is the actually useful
number for a hackathon pitch.

When the real NASA dataset (released Oct 28) has enough rows for a normal
train/test split, swap `leave_one_out_accuracy()` for a standard
train_test_split + accuracy_score, and this caveat becomes unnecessary.
"""

import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import LeaveOneOut, cross_val_score
from sklearn.preprocessing import LabelEncoder

FEATURE_COLUMNS = ["oxygen_pct", "airflow_cms", "material", "sample_geometry"]
TARGET_COLUMN = "extinguished"

MIN_ROWS_FOR_ML = 30  # rule of thumb; below this, treat results as illustrative only


def prepare_features(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Encode categorical columns (material, sample_geometry) as integers."""
    X = df[FEATURE_COLUMNS].copy()
    encoders = {}
    for col in ["material", "sample_geometry"]:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col])
        encoders[col] = le
    return X, encoders


def train_and_evaluate(df: pd.DataFrame) -> dict:
    """
    Train a small decision tree to predict 'extinguished' from experiment
    conditions, evaluated with leave-one-out CV. Returns accuracy, feature
    importances, and an explicit reliability flag.
    """
    X, encoders = prepare_features(df)
    y = df[TARGET_COLUMN].astype(int)

    model = DecisionTreeClassifier(max_depth=3, random_state=42)

    loo = LeaveOneOut()
    scores = cross_val_score(model, X, y, cv=loo)
    accuracy = scores.mean()

    # Fit on all data (for feature importance / final model), separate from
    # the LOO accuracy estimate above — importances describe the full-data
    # fit, accuracy describes generalization.
    model.fit(X, y)
    importances = dict(zip(FEATURE_COLUMNS, model.feature_importances_))

    return {
        "accuracy": accuracy,
        "n_samples": len(df),
        "reliable": len(df) >= MIN_ROWS_FOR_ML,
        "feature_importances": importances,
        "model": model,
        "encoders": encoders,
    }


def explain_result(result: dict) -> str:
    """Plain-language, honestly-caveated explanation of the ML result."""
    top_feature = max(result["feature_importances"], key=result["feature_importances"].get)
    base = (
        f"Using leave-one-out cross-validation on {result['n_samples']} experiments, "
        f"a decision tree predicted whether a flame self-extinguished with "
        f"{result['accuracy']*100:.0f}% accuracy. "
        f"'{top_feature}' had the strongest influence on the prediction."
    )
    if not result["reliable"]:
        base += (
            f" ⚠️ With only {result['n_samples']} samples, this result is illustrative "
            f"of the approach, not a validated finding — re-run this once the official, "
            f"larger NASA dataset is available."
        )
    return base


if __name__ == "__main__":
    from pipeline import load_data, clean_data

    df = clean_data(load_data("data/experiments_sample.csv"))
    result = train_and_evaluate(df)
    print(explain_result(result))
    print("\nFeature importances:")
    for feat, imp in sorted(result["feature_importances"].items(), key=lambda x: -x[1]):
        print(f"  {feat}: {imp:.2f}")
