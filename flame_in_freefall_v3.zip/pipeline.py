"""
Flame in Freefall — core data pipeline (V1)

This is the minimum viable pipeline for the hackathon:
  NASA-style experiment data -> clean -> plain-language plain-language experiment summary -> ranked table

IMPORTANT: The data in data/experiments_sample.csv is a hand-built PROTOTYPE
dataset based on publicly documented characteristics of NASA's real BASS-II
and FLEX-2 microgravity combustion experiments (ISS operations reports).
It is NOT the official challenge dataset — that will be released by NASA
on October 28. Swap this file out for the real data once it drops; the
pipeline below is written to work with the same column structure.
"""

import pandas as pd


REQUIRED_COLUMNS = [
    "experiment_id", "mission", "material", "oxygen_pct", "airflow_cms",
    "sample_geometry", "flame_behavior", "spread_rate_mm_s", "extinguished",
    "source_note",
]


def load_data(path: str) -> pd.DataFrame:
    """Load the experiment CSV and do basic validation."""
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing expected columns: {missing}")
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning: drop empty rows, fix types, normalize text fields."""
    df = df.dropna(subset=["experiment_id", "material"]).copy()

    # Ensure numeric columns are numeric (coerce bad values to NaN, then drop)
    for col in ["oxygen_pct", "airflow_cms", "spread_rate_mm_s"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["oxygen_pct", "airflow_cms", "spread_rate_mm_s"])

    # Normalize boolean-like column
    df["extinguished"] = df["extinguished"].astype(str).str.strip().str.lower() == "true"

    # Trim whitespace on text fields
    for col in ["mission", "material", "sample_geometry", "flame_behavior", "source_note"]:
        df[col] = df[col].astype(str).str.strip()

    return df.reset_index(drop=True)


def summarize_row(row: pd.Series) -> str:
    """
    Rule-based 'experiment summary' layer.

    This is intentionally template-based rather than calling an external LLM,
    so the pipeline works fully offline and with zero API cost/latency risk
    during the hackathon. It reads real values from the row — it never
    invents numbers. If you want to upgrade this to use an LLM (e.g. to vary
    phrasing or handle edge cases more naturally), keep this function's
    output as the "ground truth" facts you pass into the LLM prompt, and
    have the LLM rephrase only — never let it introduce new numbers or claims.
    """
    outcome = "self-extinguished" if row["extinguished"] else "continued to spread"
    material_lower = row["material"].lower()
    article = "an" if material_lower[0] in "aeiou" else "a"
    return (
        f"In this {row['mission']} test, {article} {material_lower} sample "
        f"({row['sample_geometry'].lower()}) was exposed to {row['oxygen_pct']:.0f}% "
        f"oxygen with airflow of {row['airflow_cms']:.0f} cm/s. The flame "
        f"{outcome}, with an observed spread rate of {row['spread_rate_mm_s']:.1f} mm/s."
    )


def safety_note(row: pd.Series) -> str:
    """
    Careful, responsible phrasing: describes what was OBSERVED, never claims
    a material is inherently 'dangerous' or 'safe'. See the discussion on
    scientifically responsible framing.
    """
    if row["extinguished"]:
        return "Observed conditions were associated with the flame self-extinguishing."
    if row["spread_rate_mm_s"] >= 4.0:
        return "Observed conditions were associated with a comparatively high flame spread rate."
    return "Observed conditions were associated with sustained, slower flame spread."


def build_report(df: pd.DataFrame) -> pd.DataFrame:
    """Attach the experiment summary and safety note columns, ranked by spread rate."""
    df = df.copy()
    df["experiment_summary"] = df.apply(summarize_row, axis=1)
    df["safety_note"] = df.apply(safety_note, axis=1)
    df = df.sort_values("spread_rate_mm_s", ascending=False).reset_index(drop=True)
    return df


def compare_experiments(row_a: pd.Series, row_b: pd.Series) -> str:
    """
    Rule-based comparison narrative between two experiments. Same principle
    as summarize_row(): describes observed differences, never claims
    causation the data doesn't support.
    """
    diffs = []
    for col, label in [
        ("oxygen_pct", "oxygen level"), ("airflow_cms", "airflow"),
        ("material", "material"), ("sample_geometry", "geometry"),
    ]:
        if row_a[col] != row_b[col]:
            diffs.append(label)

    if not diffs:
        shared = "all recorded conditions"
    else:
        shared = "everything except " + ", ".join(diffs)

    outcome_a = "self-extinguished" if row_a["extinguished"] else "continued to spread"
    outcome_b = "self-extinguished" if row_b["extinguished"] else "continued to spread"

    return (
        f"{row_a['experiment_id']} and {row_b['experiment_id']} share {shared}. "
        f"{row_a['experiment_id']} {outcome_a} (spread rate {row_a['spread_rate_mm_s']:.1f} mm/s); "
        f"{row_b['experiment_id']} {outcome_b} (spread rate {row_b['spread_rate_mm_s']:.1f} mm/s). "
        f"This is an observed difference — the data doesn't establish which "
        f"varying factor(s) caused it without further analysis."
    )


if __name__ == "__main__":
    raw = load_data("data/experiments_sample.csv")
    cleaned = clean_data(raw)
    report = build_report(cleaned)

    print(f"Loaded {len(report)} experiments.\n")
    for _, row in report.iterrows():
        print(f"[{row['experiment_id']}] {row['experiment_summary']}")
        print(f"   -> {row['safety_note']}\n")
